package com.cg.payroll.controller;

import org.springframework.stereotype.Controller;

@Controller
public class PayrollServiceController {

}
