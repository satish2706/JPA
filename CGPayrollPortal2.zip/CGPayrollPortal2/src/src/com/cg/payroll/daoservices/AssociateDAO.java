package src.com.cg.payroll.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import src.com.cg.payroll.beans.Associate;

public interface AssociateDAO extends JpaRepository<Associate,Integer> {

}
